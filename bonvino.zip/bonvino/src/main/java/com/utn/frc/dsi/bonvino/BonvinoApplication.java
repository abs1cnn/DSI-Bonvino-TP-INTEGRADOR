package com.utn.frc.dsi.bonvino;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BonvinoApplication {

	public static void main(String[] args) {
		SpringApplication.run(BonvinoApplication.class, args);
	}

}
