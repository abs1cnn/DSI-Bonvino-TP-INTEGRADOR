package com.utn.frc.dsi.bonvino;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BonvinoApplicationTests {

	@Test
	void contextLoads() {
	}

}
